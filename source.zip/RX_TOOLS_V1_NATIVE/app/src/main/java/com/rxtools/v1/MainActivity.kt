package com.rxtools.v1

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import android.provider.Settings.Secure

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 11)
    private val panel = Color.rgb(25, 25, 30)
    private val red = Color.rgb(255, 48, 72)
    private val white = Color.WHITE
    private val muted = Color.rgb(175, 175, 185)
    private val prefs by lazy { getSharedPreferences("rx_restore", Context.MODE_PRIVATE) }
    private val keyPrefs by lazy { getSharedPreferences("rx_key_store", Context.MODE_PRIVATE) }
    private val developerKey = "RX-TOOLS-V1"
    private val toggles = linkedMapOf<String, Switch>()
    private var pointerBar: SeekBar? = null
    private var brightnessBar: SeekBar? = null
    private var statusText: TextView? = null
    private var resultText: TextView? = null
    private var originalPointer: Int? = null
    private var originalTimeout: Int? = null
    private var originalBrightness: Int? = null
    private var touchEventCount = 0
    private var dragEventCount = 0

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showLogin() }

    private fun base(title: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(18), dp(16), dp(18), dp(20)) }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.rx_tools_logo)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            contentDescription = "Logo RX TOOLS"
            adjustViewBounds = true
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, dp(156)))
        val head = TextView(this).apply { text = title; textSize = 23f; setTextColor(red); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16)) }
        root.addView(head, LinearLayout.LayoutParams(-1, -2))
        return root
    }
    private fun text(s: String, size: Float = 14f, color: Int = white) = TextView(this).apply { text = s; textSize = size; setTextColor(color); setPadding(dp(2), dp(5), dp(2), dp(5)) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text = s; setTextColor(white); setBackgroundColor(red); isAllCaps = false; setOnClickListener { action() } }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(panel) }
    private fun addGap(root: LinearLayout, h: Int = 10) { root.addView(View(this), LinearLayout.LayoutParams(1, dp(h))) }
    private fun scroll(root: LinearLayout) { setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) }) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showLogin() {
        val root = base("RX TOOLS V1 NATIVE")
        root.gravity = Gravity.CENTER_HORIZONTAL
        addGap(root, 48)
        root.addView(text("ACCESS KEY • ONE DEVICE PER KEY", 12f, muted))
        addGap(root, 16)
        val c = card()
        c.addView(text("MASUKKAN KEY", 13f, red))
        val key = EditText(this).apply { hint = "Tulis key lalu tekan ENTER"; setHintTextColor(muted); setTextColor(white); setSingleLine(true); imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE; setBackgroundColor(Color.rgb(40,40,45)); setPadding(dp(10), dp(10), dp(10), dp(10)) }
        c.addView(key, LinearLayout.LayoutParams(-1, -2))
        val status = text("Key terikat ke satu perangkat saat aktivasi pertama.", 12f, muted)
        c.addView(status)
        root.addView(c, LinearLayout.LayoutParams(-1, -2)); addGap(root, 12)
        val enterAction = { val result = validateAndActivateKey(key.text.toString()); status.text = result.second; if (result.first == "developer" || result.first == "reseller") showKeyManager(result.first == "developer") else if (result.first == "user") showDeviceInfo() }
        root.addView(button("ENTER / MASUK", enterAction), LinearLayout.LayoutParams(-1, dp(50))); addGap(root, 8)
        root.addView(button("RESET KEY", { key.setText(""); status.text = "Kolom key dikosongkan." }), LinearLayout.LayoutParams(-1, dp(46)))
        addGap(root, 14)
        root.addView(text("Developer key bawaan: RX-TOOLS-V1", 12f, muted))
        root.addView(text("Catatan: sistem key ini tersimpan lokal di perangkat, belum memakai server lisensi. Jangan anggap aman dari modifikasi aplikasi.", 11f, muted))
        key.setOnEditorActionListener { _, actionId, _ -> if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) { enterAction(); true } else false }
        scroll(root)
    }

    private fun deviceId(): String = Secure.getString(contentResolver, Secure.ANDROID_ID) ?: "unknown-device"

    private fun readKeys(): JSONArray = try { JSONArray(keyPrefs.getString("keys", "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveKeys(keys: JSONArray) { keyPrefs.edit().putString("keys", keys.toString()).apply() }

    private fun validateAndActivateKey(raw: String): Pair<String, String> {
        val key = raw.trim()
        if (key.isEmpty()) return "invalid" to "Masukkan key terlebih dahulu."
        if (key == developerKey) { keyPrefs.edit().putString("current_role", "developer").apply(); return "developer" to "Developer terverifikasi pada aplikasi lokal." }
        val keys = readKeys()
        for (i in 0 until keys.length()) {
            val item = keys.optJSONObject(i) ?: continue
            if (!item.optString("key").equals(key, true)) continue
            var expires = item.optLong("expiresAt", 0L)
            val permanent = item.optBoolean("permanent", false)
            if (!permanent && expires != 0L && System.currentTimeMillis() >= expires) return "invalid" to "Key sudah kedaluwarsa. Buat key baru atau hubungi pembuat key."
            val thisDevice = deviceId()
            val bound = item.optString("deviceId", "")
            if (bound.isNotBlank() && bound != thisDevice) return "invalid" to "Key sudah terikat ke perangkat lain. Satu key hanya untuk satu device."
            item.put("deviceId", thisDevice)
            val activation = if (item.optLong("activatedAt", 0L) == 0L) System.currentTimeMillis() else item.optLong("activatedAt")
            item.put("activatedAt", activation)
            if (!permanent && expires == 0L) { expires = activation + item.optLong("durationDays", 1L) * 24L * 60L * 60L * 1000L; item.put("expiresAt", expires) }
            item.put("status", "active")
            saveKeys(keys)
            val role = item.optString("type", "user")
            keyPrefs.edit().putString("current_role", role).putString("current_key", key).apply()
            return role to "Key valid • ${role.uppercase(Locale.ROOT)} • perangkat ini sudah terikat."
        }
        return "invalid" to "Key tidak ditemukan atau salah."
    }

    private fun showKeyManager(isDeveloper: Boolean) {
        val root = base(if (isDeveloper) "DEVELOPER • KEY MANAGER" else "RESELLER • KEY MANAGER")
        val intro = card()
        intro.addView(text(if (isDeveloper) "Developer: dapat membuat key USER dan RESELLER." else "Reseller: hanya dapat membuat key USER. Masa aktif key reseller dikelola developer.", 13f, muted))
        root.addView(intro, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        val create = card(); create.addView(text("BUAT KEY BARU", 14f, red))
        create.addView(text("Nama key (unik)", 12f, muted))
        val keyInput = EditText(this).apply { hint = "Contoh: RX-USER-001"; setHintTextColor(muted); setTextColor(white); setSingleLine(true); setBackgroundColor(Color.rgb(40,40,45)); setPadding(dp(10), dp(8), dp(10), dp(8)) }
        create.addView(keyInput, LinearLayout.LayoutParams(-1, dp(48)))
        create.addView(text("Jenis key", 12f, muted))
        val typeSpinner = Spinner(this)
        typeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, if (isDeveloper) listOf("User", "Reseller") else listOf("User"))
        create.addView(typeSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        create.addView(text("Masa aktif", 12f, muted))
        val durationSpinner = Spinner(this)
        fun updateDurations() {
            val isReseller = isDeveloper && typeSpinner.selectedItem?.toString() == "Reseller"
            val choices = if (isReseller) listOf("1 minggu", "1 bulan", "Permanen") else listOf("1 hari", "2 hari", "3 hari", "4 hari", "5 hari", "1 minggu", "1 bulan", "Permanen")
            durationSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices)
        }
        typeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { updateDurations() }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        updateDurations(); create.addView(durationSpinner, LinearLayout.LayoutParams(-1, dp(48)))
        val createStatus = text("Key akan aktif setelah disimpan; masa aktif dihitung sejak aktivasi pertama.", 12f, muted)
        create.addView(createStatus)
        create.addView(button("BUAT KEY", {
            val newKey = keyInput.text.toString().trim()
            if (newKey.length < 4 || newKey.any { it.isWhitespace() }) { createStatus.text = "Gagal: key minimal 4 karakter dan tanpa spasi."; return@button }
            val keys = readKeys()
            if (newKey.equals(developerKey, true) || (0 until keys.length()).any { keys.optJSONObject(it)?.optString("key")?.equals(newKey, true) == true }) { createStatus.text = "Gagal: key sudah ada atau memakai key developer."; return@button }
            val type = if (isDeveloper) typeSpinner.selectedItem.toString().lowercase(Locale.ROOT) else "user"
            val duration = durationSpinner.selectedItem?.toString() ?: "1 hari"
            val millis = when (duration) { "1 hari" -> 1L; "2 hari" -> 2L; "3 hari" -> 3L; "4 hari" -> 4L; "5 hari" -> 5L; "1 minggu" -> 7L; "1 bulan" -> 30L; else -> 0L }
            val expiresAt = 0L // masa aktif dimulai saat aktivasi pertama
            keys.put(JSONObject().put("key", newKey).put("type", type).put("duration", duration).put("durationDays", millis).put("permanent", millis == 0L).put("createdAt", System.currentTimeMillis()).put("expiresAt", expiresAt).put("activatedAt", 0L).put("deviceId", "").put("createdBy", if (isDeveloper) developerKey else keyPrefs.getString("current_key", "reseller" )).put("status", "unused"))
            saveKeys(keys); keyInput.setText(""); createStatus.text = "Key $newKey berhasil dibuat • $type • $duration"; showKeyManager(isDeveloper)
        }), LinearLayout.LayoutParams(-1, dp(48)))
        root.addView(create, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        val list = card(); list.addView(text("DAFTAR KEY", 14f, red))
        val keys = readKeys()
        if (keys.length() == 0) list.addView(text("Belum ada key dibuat.", 12f, muted))
        for (i in 0 until keys.length()) {
            val item = keys.optJSONObject(i) ?: continue
            if (!isDeveloper && item.optString("createdBy") != keyPrefs.getString("current_key", "")) continue
            val expires = item.optLong("expiresAt", 0L)
            val permanent = item.optBoolean("permanent", false)
            val expired = !permanent && expires != 0L && System.currentTimeMillis() >= expires
            val device = item.optString("deviceId", "")
            val status = when { expired -> "KEDALUWARSA"; device.isBlank() -> "BELUM DIPAKAI"; else -> "TERIKAT / AKTIF" }
            val expText = when { permanent -> "Permanen"; expires == 0L -> "Mulai saat aktivasi pertama"; else -> SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault()).format(Date(expires)) }
            list.addView(text("${item.optString("key")}
Jenis: ${item.optString("type").uppercase(Locale.ROOT)} • Masa: ${item.optString("duration")}
Berakhir: $expText
Device: ${if (device.isBlank()) "belum terikat" else device.take(8) + "…"}
Status: $status", 12f, if (expired) red else white))
            list.addView(View(this).apply { setBackgroundColor(Color.DKGRAY) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
        root.addView(list, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        root.addView(button("BUKA OPTIMIZER", { showDeviceInfo() }), LinearLayout.LayoutParams(-1, dp(50))); addGap(root)
        root.addView(button("KELUAR / GANTI KEY", { showLogin() }), LinearLayout.LayoutParams(-1, dp(46)))
        scroll(root)
    }

    private fun showDeviceInfo() {
        val root = base("DEVICE INFO + TOUCH CHECK")
        val c = card()
        c.addView(text("Merek: ${Build.MANUFACTURER}", 14f))
        c.addView(text("Model: ${Build.MODEL}", 14f))
        c.addView(text("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", 14f))
        c.addView(text("Build: ${Build.DISPLAY}", 12f, muted))
        c.addView(text("Shizuku: ${shizukuStatus()}", 14f, if (shizukuStatus().contains("aktif")) Color.GREEN else muted))
        root.addView(c, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        root.addView(text("SENTUH DAN GESER AREA DI BAWAH INI", 13f, red))
        val touch = TouchPad(this).apply { setBackgroundColor(Color.rgb(35, 20, 25)) }
        root.addView(touch, LinearLayout.LayoutParams(-1, dp(190)))
        addGap(root)
        root.addView(button("LANJUT KE OPTIMIZER", { showDashboard() }), LinearLayout.LayoutParams(-1, dp(52)))
        scroll(root)
    }

    private fun shizukuStatus(): String = try {
        if (Shizuku.pingBinder()) {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "aktif + izin diberikan" else "aktif, izin belum diberikan"
        } else "tidak aktif"
    } catch (_: Throwable) { "tidak tersedia" }

    private val featureNames = listOf(
        "Sensitivity", "Sensitivity XY", "Touch Response", "Drag Response",
        "Performance Optimization", "Game Optimization", "Smooth Touch",
        "Screen Response", "Aim Response", "System Optimization",
        "RAM Cleaner", "Cache Cleaner", "Aim Stability Control",
        "Touch Response Optimization", "Sensitivity Calibration System",
        "Frame Rate Stabilizer", "Network Latency Optimizer",
        "Background App Cleaner", "Thermal Control Management",
        "Graphic Rendering Optimizer", "Game Mode Activation"
    )

    private fun showDashboard() {
        toggles.clear()
        val root = base("RX TOOLS • OPTIMIZER")
        val stat = card()
        statusText = text("Status: siap • cek izin sebelum menerapkan", 13f, muted)
        stat.addView(statusText)
        stat.addView(text("Fitur ON hanya menjalankan tindakan yang benar-benar didukung perangkat.", 12f, muted))
        root.addView(stat, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        val controls = card()
        controls.addView(text("DISPLAY / INPUT", 14f, red))
        controls.addView(text("Pointer speed (Android system setting)", 12f, muted))
        pointerBar = SeekBar(this).apply { max = 14; progress = readPointerSpeed() + 7; if (progress !in 0..14) progress = 7 }
        controls.addView(pointerBar, LinearLayout.LayoutParams(-1, -2))
        controls.addView(text("Nilai pointer speed: ${pointerBar!!.progress - 7}", 12f, muted))
        pointerBar!!.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { controls.getChildAt(1).let { (it as TextView).text = "Nilai pointer speed: ${p - 7}" } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        controls.addView(text("Screen brightness", 12f, muted))
        brightnessBar = SeekBar(this).apply { max = 100; progress = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) * 100 / 255 } catch (_: Exception) { 50 } }
        controls.addView(brightnessBar, LinearLayout.LayoutParams(-1, -2))
        root.addView(controls, LinearLayout.LayoutParams(-1, -2)); addGap(root)

        val listCard = card(); listCard.addView(text("OPTIMIZATION TOGGLES", 14f, red))
        featureNames.forEach { name ->
            val sw = Switch(this).apply { text = name; textSize = 14f; setTextColor(white); isChecked = name in listOf("Touch Response", "Drag Response", "Performance Optimization", "Smooth Touch", "Frame Rate Stabilizer", "Thermal Control Management") }
            toggles[name] = sw; listCard.addView(sw, LinearLayout.LayoutParams(-1, -2))
        }
        root.addView(listCard, LinearLayout.LayoutParams(-1, -2)); addGap(root)

        // Resolution / density panel sits between feature toggles and INJECT actions.
        val displayCard = card()
        displayCard.addView(text("RESOLUTION • DPI / DENSITY", 14f, red))
        displayCard.addView(text("Ubah ukuran tampilan Android. Memerlukan Shizuku aktif + izin; tidak mengubah setting internal Free Fire.", 12f, muted))
        val dm = resources.displayMetrics
        val resolutionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val widthInput = EditText(this).apply {
            hint = "Lebar"; setHintTextColor(muted); setTextColor(white); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); setBackgroundColor(Color.rgb(40,40,45)); setPadding(dp(10), dp(8), dp(10), dp(8)); setText(dm.widthPixels.toString())
        }
        val heightInput = EditText(this).apply {
            hint = "Tinggi"; setHintTextColor(muted); setTextColor(white); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); setBackgroundColor(Color.rgb(40,40,45)); setPadding(dp(10), dp(8), dp(10), dp(8)); setText(dm.heightPixels.toString())
        }
        resolutionRow.addView(widthInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        resolutionRow.addView(text(" × ", 16f, red))
        resolutionRow.addView(heightInput, LinearLayout.LayoutParams(0, dp(48), 1f))
        displayCard.addView(resolutionRow, LinearLayout.LayoutParams(-1, -2)); addGap(displayCard, 8)
        displayCard.addView(text("Density (dpi)", 12f, muted))
        val densityInput = EditText(this).apply {
            hint = "Contoh: 420"; setHintTextColor(muted); setTextColor(white); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true); setBackgroundColor(Color.rgb(40,40,45)); setPadding(dp(10), dp(8), dp(10), dp(8)); setText(dm.densityDpi.toString())
        }
        displayCard.addView(densityInput, LinearLayout.LayoutParams(-1, dp(48))); addGap(displayCard, 8)
        val displayStatus = text("Status: belum ada perubahan resolusi/density.", 12f, muted)
        displayCard.addView(button("APPLY RESOLUTION + DENSITY", {
            val w = widthInput.text.toString().toIntOrNull()
            val h = heightInput.text.toString().toIntOrNull()
            val d = densityInput.text.toString().toIntOrNull()
            if (w == null || h == null || d == null || w !in 480..4000 || h !in 800..8000 || d !in 120..1000) {
                displayStatus.text = "Gagal: isi lebar 480–4000, tinggi 800–8000, density 120–1000 dpi."
                return@button
            }
            if (!hasShizukuPermission()) {
                displayStatus.text = "Gagal: aktifkan service Shizuku dan berikan izin RX TOOLS terlebih dahulu."
                return@button
            }
            try {
                val sizeResult = runShizukuCommand("wm size ${w}x${h}")
                if (sizeResult.exitCode != 0) throw IllegalStateException("wm size gagal: ${sizeResult.output}")
                val densityResult = runShizukuCommand("wm density $d")
                if (densityResult.exitCode != 0) {
                    runCatching { runShizukuCommand("wm size reset") }
                    throw IllegalStateException("wm density gagal: ${densityResult.output}")
                }
                displayStatus.text = "APPLY berhasil diverifikasi oleh shell. Resolusi ${w}×${h}, density ${d} dpi. Jika UI terlihat aneh, tekan RESET."
                statusText?.text = "Resolusi/density diterapkan • ${w}×${h} • ${d} dpi"
            } catch (e: Exception) {
                displayStatus.text = "APPLY gagal: ${e.message ?: e.javaClass.simpleName}"
            }
        }), LinearLayout.LayoutParams(-1, dp(48))); addGap(displayCard, 8)
        displayCard.addView(button("RESET RESOLUTION + DENSITY", {
            if (!hasShizukuPermission()) {
                displayStatus.text = "RESET gagal: aktifkan service Shizuku dan berikan izin terlebih dahulu."
                return@button
            }
            try {
                val sizeResult = runShizukuCommand("wm size reset")
                val densityResult = runShizukuCommand("wm density reset")
                if (sizeResult.exitCode == 0 && densityResult.exitCode == 0) {
                    displayStatus.text = "RESET berhasil: resolusi dan density dikembalikan ke default Android/OEM."
                    statusText?.text = "Resolusi/density kembali ke default"
                } else {
                    displayStatus.text = "RESET tidak lengkap. size: ${sizeResult.output}; density: ${densityResult.output}"
                }
            } catch (e: Exception) {
                displayStatus.text = "RESET gagal: ${e.message ?: e.javaClass.simpleName}"
            }
        }), LinearLayout.LayoutParams(-1, dp(48)))
        displayCard.addView(displayStatus)
        root.addView(displayCard, LinearLayout.LayoutParams(-1, -2)); addGap(root)

        val actions = card()
        actions.addView(button("INJECT • APPLY SELECTED", { inject() }), LinearLayout.LayoutParams(-1, dp(50))); addGap(actions)
        actions.addView(button("RESTORE ALL • MANUAL", { restoreAll() }), LinearLayout.LayoutParams(-1, dp(50))); addGap(actions)
        actions.addView(button("BUKA FREE FIRE", { launchGame(false) }), LinearLayout.LayoutParams(-1, dp(48))); addGap(actions)
        actions.addView(button("BUKA FREE FIRE MAX", { launchGame(true) }), LinearLayout.LayoutParams(-1, dp(48)))
        resultText = text("Belum ada tindakan diterapkan.", 13f, muted); actions.addView(resultText)
        root.addView(actions, LinearLayout.LayoutParams(-1, -2)); addGap(root)
        root.addView(button("CEK SHIZUKU / MINTA IZIN", { requestShizuku() }), LinearLayout.LayoutParams(-1, dp(48)))
        scroll(root)
    }

    private fun directoryBytes(file: java.io.File): Long {
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        return file.listFiles()?.sumOf { directoryBytes(it) } ?: 0L
    }

    private data class ShellResult(val exitCode: Int, val output: String)

    private fun hasShizukuPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    @Suppress("DEPRECATION")
    private fun runShizukuCommand(command: String): ShellResult {
        if (!hasShizukuPermission()) throw SecurityException("Shizuku tidak aktif atau izin belum diberikan")
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val stdout = process.inputStream.bufferedReader().use { it.readText() }
        val stderr = process.errorStream.bufferedReader().use { it.readText() }
        val code = process.waitFor()
        process.destroy()
        return ShellResult(code, (stdout + if (stderr.isBlank()) "" else "\n$stderr").trim())
    }

    private fun readPointerSpeed(): Int = try { Settings.System.getInt(contentResolver, "pointer_speed", 0) } catch (_: Exception) { 0 }
    private fun inject() {
        var success = 0
        var failed = 0
        val messages = mutableListOf<String>()
        val selected = toggles.filterValues { it.isChecked }.keys.toList()
        if (selected.isEmpty()) { resultText?.text = "Tidak ada fitur ON. Aktifkan minimal satu fitur."; return }

        val needsWriteSettings = selected.any { it == "Sensitivity" }
        if (needsWriteSettings && !Settings.System.canWrite(this)) {
            statusText?.text = "Izin ubah pengaturan sistem diperlukan"
            resultText?.text = "Berikan izin Modify system settings, lalu tekan INJECT lagi."
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return
        }

        selected.forEach { name ->
            try {
                when (name) {
                    "Sensitivity" -> {
                        val v = (pointerBar?.progress ?: 7) - 7
                        val old = readPointerSpeed()
                        prefs.edit().putInt("old_pointer", old).putBoolean("has_pointer", true).apply()
                        if (!Settings.System.canWrite(this)) throw SecurityException("Izin Modify system settings belum diberikan")
                        Settings.System.putInt(contentResolver, "pointer_speed", v)
                        if (readPointerSpeed() == v) { success++; messages.add("Sensitivity: pointer speed sistem diterapkan dan diverifikasi ($v). Tidak mengubah slider sensitivitas FF.") }
                        else { failed++; messages.add("Sensitivity: nilai pointer tidak cocok setelah diterapkan") }
                    }
                    "Sensitivity XY", "Touch Response", "Drag Response", "Aim Response", "Aim Stability Control", "Touch Response Optimization", "Sensitivity Calibration System" -> {
                        val needsDrag = name in listOf("Sensitivity XY", "Drag Response", "Aim Stability Control")
                        val count = if (needsDrag) dragEventCount else touchEventCount
                        if (count > 0) {
                            success++
                            messages.add("$name: terverifikasi dari tes input lokal ($count ${if (needsDrag) "gerakan drag" else "kejadian sentuhan"}). Ini diagnostik; tidak mengubah aim/sensitivitas internal FF.")
                        } else {
                            failed++
                            messages.add("$name: belum ada data tes. Kembali ke layar Touch Check, sentuh/geser area tes, lalu jalankan INJECT lagi.")
                        }
                    }
                    "Performance Optimization", "Game Optimization", "RAM Cleaner" -> {
                        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
                        val mi = android.app.ActivityManager.MemoryInfo()
                        am.getMemoryInfo(mi)
                        val thermal = if (Build.VERSION.SDK_INT >= 29) (getSystemService(POWER_SERVICE) as android.os.PowerManager).currentThermalStatus else -1
                        success++
                        messages.add("$name: pemeriksaan sistem selesai; RAM tersedia ${mi.availMem / (1024*1024)} MB / ${mi.totalMem / (1024*1024)} MB; lowMemory=${mi.lowMemory}; thermalStatus=$thermal. Tidak memaksa-kill proses lain.")
                    }
                    "Smooth Touch", "Screen Response", "Frame Rate Stabilizer", "Graphic Rendering Optimizer" -> {
                        @Suppress("DEPRECATION")
                        val display = windowManager.defaultDisplay
                        val hz = display.refreshRate
                        val modes = if (Build.VERSION.SDK_INT >= 23) display.supportedModes.joinToString { "${it.physicalWidth}x${it.physicalHeight}@${"%.1f".format(Locale.US, it.refreshRate)}Hz" } else "informasi mode lanjutan tidak tersedia"
                        success++
                        messages.add("$name: refresh rate aktual ${"%.1f".format(Locale.US, hz)} Hz; mode layar: $modes. Ini bukan pembacaan FPS internal game.")
                    }
                    "Cache Cleaner" -> {
                        val bytes = directoryBytes(cacheDir) + directoryBytes(codeCacheDir)
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                        startActivity(intent)
                        success++
                        messages.add("Cache Cleaner: cache milik RX TOOLS ${bytes / 1024} KB; halaman info aplikasi dibuka untuk pembersihan manual. Cache FF tidak dihapus otomatis karena batas Android.")
                    }
                    "Network Latency Optimizer" -> {
                        if (!isNetworkConnected()) {
                            failed++; messages.add("Network Latency Optimizer: tidak ada koneksi jaringan aktif yang terdeteksi.")
                        } else {
                            success++
                            messages.add("Network Latency Optimizer: koneksi jaringan terdeteksi. Pengukuran ping ke server FF belum tersedia; ini bukan klaim ping turun.")
                        }
                    }
                    "Background App Cleaner" -> {
                        startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS))
                        success++
                        messages.add("Background App Cleaner: daftar aplikasi dibuka agar kamu bisa menghentikan aplikasi non-esensial secara manual. Android membatasi penghentian aplikasi lain.")
                    }
                    "Thermal Control Management" -> {
                        if (Build.VERSION.SDK_INT >= 29) {
                            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                            val thermal = when (pm.currentThermalStatus) { 0 -> "NONE"; 1 -> "LIGHT"; 2 -> "MODERATE"; 3 -> "SEVERE"; 4 -> "CRITICAL"; 5 -> "EMERGENCY"; 6 -> "SHUTDOWN"; else -> "UNKNOWN" }
                            success++; messages.add("Thermal Control Management: status termal $thermal. Aplikasi hanya memantau, tidak dapat mengendalikan pendinginan fisik.")
                        } else { failed++; messages.add("Thermal Control Management: API status termal tidak tersedia di versi Android ini.") }
                    }
                    "System Optimization" -> {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                        success++
                        messages.add("System Optimization: Pengaturan Android dibuka agar pengaturan sistem/performa yang tersedia dapat dipilih manual.")
                    }
                    "Game Mode Activation" -> {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                        success++
                        messages.add("Game Mode Activation: Pengaturan Android dibuka. Aktifkan Game Mode bawaan bila disediakan produsen HP.")
                    }
                }
            } catch (e: Exception) {
                failed++
                messages.add("$name: gagal (${e.message ?: e.javaClass.simpleName})")
            }
        }
        val total = success + failed
        val pct = if (total == 0) 0 else success * 100 / total
        statusText?.text = "Selesai • $success berhasil • $failed gagal"
        resultText?.text = "Hasil aksi terverifikasi: $pct% ($success/$total). Ini bukan persentase peningkatan FPS.\n" + messages.joinToString("\n")
    }

    private fun isNetworkConnected(): Boolean = try {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val network = cm.activeNetwork
        network != null && cm.getNetworkCapabilities(network)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
    } catch (_: Exception) { false }

    private fun restoreAll() {
        var ok = 0; var bad = 0; val lines = mutableListOf<String>()
        if (!Settings.System.canWrite(this) && (prefs.getBoolean("has_pointer", false) || prefs.getBoolean("has_brightness", false) || prefs.getBoolean("has_timeout", false))) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            resultText?.text = "Izin Modify system settings diperlukan untuk restore."; return
        }
        fun restore(key: String, has: String, setting: String) {
            if (!prefs.getBoolean(has, false)) return
            try {
                val value = prefs.getInt(key, 0); Settings.System.putInt(contentResolver, setting, value)
                val actual = Settings.System.getInt(contentResolver, setting)
                if (actual == value) { ok++; lines.add("$setting dipulihkan") } else { bad++; lines.add("$setting verifikasi restore gagal") }
            } catch (_: Exception) { bad++; lines.add("$setting gagal dipulihkan") }
        }
        restore("old_pointer", "has_pointer", "pointer_speed")
        restore("old_brightness", "has_brightness", Settings.System.SCREEN_BRIGHTNESS)
        restore("old_timeout", "has_timeout", Settings.System.SCREEN_OFF_TIMEOUT)
        prefs.edit().clear().apply()
        resultText?.text = "RESTORE ALL: $ok berhasil, $bad gagal.\n" + if (lines.isEmpty()) "Tidak ada perubahan tercatat untuk dipulihkan." else lines.joinToString("\n")
        statusText?.text = "Restore selesai • $ok berhasil • $bad gagal"
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { resultText?.text = "Shizuku belum aktif. Buka aplikasi Shizuku dan mulai service."; return }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) Shizuku.requestPermission(1001)
            else resultText?.text = "Izin Shizuku sudah diberikan. Fitur tetap dibatasi kemampuan Android/OEM."
        } catch (e: Throwable) { resultText?.text = "Shizuku tidak tersedia: ${e.message}" }
    }

    private fun launchGame(max: Boolean) {
        val pkg = if (max) "com.dts.freefiremax" else "com.dts.freefireth"
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent) else Toast.makeText(this, if (max) "Free Fire MAX tidak ditemukan" else "Free Fire tidak ditemukan", Toast.LENGTH_LONG).show()
    }

    private inner class TouchPad(ctx: Context) : View(ctx) {
        private var lastX = 0f; private var lastY = 0f; private var touches = 0; private var drags = 0
        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas); val p = android.graphics.Paint().apply { color = red; textSize = dp(15).toFloat(); isAntiAlias = true }
            canvas.drawText("Sentuhan: $touches", dp(14).toFloat(), dp(30).toFloat(), p)
            canvas.drawText("Gerakan: $drags", dp(14).toFloat(), dp(56).toFloat(), p)
            p.color = muted; canvas.drawText("Tes diagnostik saja — bukan tes input internal FF", dp(14).toFloat(), dp(82).toFloat(), p)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) { MotionEvent.ACTION_DOWN -> { touches++; touchEventCount++; lastX=event.x; lastY=event.y; invalidate(); return true }; MotionEvent.ACTION_MOVE -> { if (kotlin.math.abs(event.x-lastX)+kotlin.math.abs(event.y-lastY)>5) { drags++; dragEventCount++ }; lastX=event.x; lastY=event.y; invalidate(); return true }; MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { performClick(); invalidate(); return true } }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }
}
