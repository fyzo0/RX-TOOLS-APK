# RX TOOLS V1 NATIVE — source project

Native Android/Kotlin dashboard for Android 11+ (minSdk 30), with a red/black UI, local demo login, device diagnostics, touch test, 21 feature toggles, INJECT result reporting, manual RESTORE ALL, resolution + DPI/density panel (APPLY/RESET via Shizuku `wm` commands), Shizuku status/permission request, and launch buttons for Free Fire / Free Fire MAX.

## Build
Open this folder in Android Studio with Android SDK 35 installed, then Sync Gradle and Build APK.

## Important behavior and limits
- INJECT executes the action assigned to each enabled toggle and reports an action-verification percentage. That percentage is NOT a measure of FPS gain or lag reduction.
- Sensitivity only applies Android pointer speed, which does not change Free Fire's in-game sensitivity slider and is most relevant to mouse/pointer input, not finger touch.
- Touch/drag/aim toggles are diagnostic helpers; they do not modify internal game aim or input processing.
- Performance/RAM features report Android memory/thermal diagnostics. Android does not let ordinary apps safely force-clean all RAM or kill other apps at will.
- Refresh-rate checks read display mode information; they do not read the game's internal FPS or force an unsupported refresh rate.
- Network action checks whether an internet-capable network is present; it does not measure Free Fire server ping or promise lower latency.
- Cache Cleaner opens this app's information page for manual cache handling. Android restricts clearing another app's cache.
- Game Mode and system helpers open Android settings; availability of OEM game modes varies by device.
- RESTORE ALL manually restores recorded pointer-speed changes. Diagnostic checks and settings pages do not need restoring. No changes are applied automatically when leaving the game.
- Resolution/DPI panel uses `wm size` and `wm density` through Shizuku shell, and requires the Shizuku service and app permission. APPLY checks command exit status; RESET runs `wm size reset` and `wm density reset` to restore Android/OEM defaults. A device/OEM may still restrict commands. Changing logical size/density can make UI/game controls too small, large, or clipped; it does not guarantee higher FPS.
- Shizuku status/permission is checked, but this source does not pretend Shizuku grants unrestricted system access.

This is source code and has not been compiled or tested on the target phone in this environment. Build and test on a device before treating it as release-ready.

## Key / Reseller Manager (prototype)
- Developer key lokal: `RX-TOOLS-V1`.
- Developer dapat membuat key User dan Reseller; Reseller hanya dapat membuat key User.
- Masa aktif key User: 1–5 hari, 1 minggu, 1 bulan, atau permanen. Masa aktif mulai saat aktivasi pertama. Masa aktif key Reseller: 1 minggu, 1 bulan, atau permanen.
- Key mengikat Android ID pada aktivasi pertama dan menolak perangkat berbeda selama data aplikasi tersedia.
- **Penting:** penyimpanan key saat ini lokal di instalasi aplikasi. Key yang dibuat tidak otomatis tersedia di HP lain. Sistem lokal bisa dimodifikasi/dilewati dan tidak cocok untuk penjualan key sungguhan. Untuk distribusi reseller lintas perangkat dan validasi yang tahan manipulasi, dibutuhkan backend/server lisensi dengan autentikasi.

## Identitas visual
Logo RX TOOLS dari referensi pengguna digunakan pada header seluruh layar aplikasi dan sebagai ikon aplikasi Android. Tema tetap merah-hitam.

## Build Android (Gradle bootstrap)

Project menyertakan `gradlew` (Linux/macOS/Termux) dan `gradlew.bat` (Windows). Jika Gradle 8.9 belum tersedia, launcher akan mencoba mengunduh distribusi Gradle resmi pada pemakaian pertama. Pastikan Java 17 atau lebih baru dan Android SDK Platform 35 serta Android SDK Build-Tools terpasang. Di Android Studio, buka folder proyek ini dan tunggu Gradle Sync, atau jalankan:

- Windows: `gradlew.bat assembleDebug`
- Linux/macOS/Termux: `./gradlew assembleDebug`

APK debug yang berhasil dibangun ada di `app/build/outputs/apk/debug/app-debug.apk`. Launcher ini memperbaiki ketiadaan perintah `gradle` global, tetapi build tetap membutuhkan internet untuk dependensi Gradle/Maven dan Android SDK yang sesuai. Proyek belum dapat dikompilasi di lingkungan pembuat ZIP karena tidak tersedia Gradle dan akses jaringan.
