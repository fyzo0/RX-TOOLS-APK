@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME_BASE=%GRADLE_USER_HOME%\rx-tools-bootstrap"
set "GRADLE_HOME=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%"
if exist "%GRADLE_HOME%\bin\gradle.bat" goto runGradle
if not exist "%GRADLE_HOME_BASE%" mkdir "%GRADLE_HOME_BASE%"
set "ZIP=%GRADLE_HOME_BASE%\gradle-%GRADLE_VERSION%-bin.zip"
echo Gradle %GRADLE_VERSION% belum tersedia; mengunduh...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
if errorlevel 1 (echo ERROR: gagal mengunduh Gradle. & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%GRADLE_HOME_BASE%' -Force"
if errorlevel 1 (echo ERROR: gagal mengekstrak Gradle. & exit /b 1)
del "%ZIP%"
:runGradle
call "%GRADLE_HOME%\bin\gradle.bat" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
